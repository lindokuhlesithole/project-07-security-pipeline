import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')

findings_table = dynamodb.Table(os.environ['FINDINGS_TABLE'])
cases_table = dynamodb.Table(os.environ['CASES_TABLE'])
sns_topic = os.environ['SNS_TOPIC_ARN']

def lambda_handler(event, context):
    """Process CloudTrail API events and create security findings"""

    detail = event.get('detail', {})
    event_name = detail.get('eventName', 'Unknown')
    event_source = detail.get('eventSource', 'Unknown')
    user = detail.get('userIdentity', {}).get('arn', 'Unknown')
    source_ip = detail.get('sourceIPAddress', 'Unknown')

    # Severity scoring based on event type
    severity_map = {
        'DeleteTrail': 8,
        'CreateAccessKey': 7,
        'PutBucketPolicy': 6,
        'AuthorizeSecurityGroupIngress': 5
    }
    severity = severity_map.get(event_name, 3)

    finding = {
        'findingId': f"{event_name}-{detail.get('eventID', 'unknown')}",
        'timestamp': datetime.utcnow().isoformat(),
        'type': f"CloudTrail:{event_name}",
        'severity': str(severity),
        'title': f"Suspicious API Call: {event_name}",
        'description': f"User {user} called {event_name} from {source_ip}",
        'resource': json.dumps({
            'eventSource': event_source,
            'user': user,
            'sourceIP': source_ip,
            'accountId': detail.get('userIdentity', {}).get('accountId', ''),
            'region': detail.get('awsRegion', '')
        }),
        'accountId': detail.get('userIdentity', {}).get('accountId', ''),
        'region': detail.get('awsRegion', ''),
        'enriched': True,
        'status': 'OPEN'
    }

    findings_table.put_item(Item=finding)

    # Create case for high severity
    if severity >= 6:
        case_id = f"CASE-{finding['findingId'][:8]}"
        cases_table.put_item(Item={
            'caseId': case_id,
            'findingId': finding['findingId'],
            'severity': finding['severity'],
            'status': 'PENDING',
            'createdAt': finding['timestamp'],
            'action': 'REQUIRES_APPROVAL'
        })

        sns.publish(
            TopicArn=sns_topic,
            Subject=f"Security Alert: {finding['title']}",
            Message=json.dumps({
                'caseId': case_id,
                'severity': finding['severity'],
                'title': finding['title'],
                'description': finding['description'],
                'action': 'REQUIRES_APPROVAL'
            }, indent=2)
        )

    return {
        'statusCode': 200,
        'body': json.dumps({
            'processed': 1,
            'severity': severity,
            'findingId': finding['findingId'],
            'message': 'Event processed and stored'
        })
    }
