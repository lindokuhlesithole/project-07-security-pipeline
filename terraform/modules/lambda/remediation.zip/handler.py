import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')

findings_table = dynamodb.Table(os.environ['FINDINGS_TABLE'])
cases_table = dynamodb.Table(os.environ['CASES_TABLE'])

def lambda_handler(event, context):
    """Review and remediate security findings"""

    # Scan for open findings
    response = findings_table.scan(
        FilterExpression='#status = :status',
        ExpressionAttributeNames={'#status': 'status'},
        ExpressionAttributeValues={':status': 'OPEN'}
    )

    remediated = 0
    for finding in response.get('Items', []):
        severity = int(finding.get('severity', 0))

        if severity <= 4:
            # Auto-remediate low severity
            findings_table.update_item(
                Key={'findingId': finding['findingId'], 'timestamp': finding['timestamp']},
                UpdateExpression='SET #status = :status, remediatedAt = :time',
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={':status': 'REMEDIATED', ':time': datetime.utcnow().isoformat()}
            )
            remediated += 1

    return {
        'statusCode': 200,
        'body': json.dumps({
            'reviewed': len(response.get('Items', [])),
            'remediated': remediated,
            'message': 'Remediation review complete'
        })
    }
